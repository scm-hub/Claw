---
name: numeric-zero-input-fix
description: 修复 React/MUI TextField type="number" 中数值为0时无法删除、无法直接输入新值的 UX 问题。当用户报告"输入框里的0删不掉"、"数量为0时需要调整光标才能输入"、"数字0无法清空"等问题时使用此 skill。触发词：0删不掉、数值无法清空、数字输入框不好用、0无法删除、quantity为0删不掉、number input 0 can't delete。
agent_created: true
---

# Numeric Zero Input Fix

## Overview

修复 React + MUI TextField `type="number"` 中数值默认为 0 时无法删除的 UX 痛点。根因是 `value={val || 0}` 用了 `||` 运算符——JavaScript 中 `0 || fallback` 返回 fallback，导致用户删掉 0 后输入框立即回填 0，永远删不掉。

## 问题模式识别

以下代码模式均会导致"0 删不掉"问题：

| 错误模式 | 说明 |
|----------|------|
| `value={qty || 0}` | `||` 对 0 返回右侧值，删空后立即回填 0 |
| `value={Number(qty) || 0}` | 同上，Number(空字符串) = 0，0 || 0 = 0 |
| `value={qty !== undefined ? qty : 0}` | 删空后 undefined → 0 回填 |
| 初始 state 设为 `planQty: 0` | 新增时默认显示 0，无法清空 |

**症状**：用户选中输入框中的 0 想输入新数字，但删掉后 0 立刻回来，必须把光标移到 0 前面才能输入。

## 修复方案（四步）

### Step 1: 改 value 绑定 — `|| 0` → `?? ''`

```jsx
// ❌ 错误：0 || 0 = 0，删不掉
<TextField type="number" value={it.planQty || 0} onChange={...} />

// ✅ 正确：0 ?? '' = 0（正常显示），'' ?? '' = ''（允许空值）
<TextField type="number" value={it.planQty ?? ''} onChange={...} />
```

`??`（nullish coalescing）只对 `null`/`undefined` 触发，0 和 '' 都原样保留。

### Step 2: 改初始 state — 数字默认值改为空字符串

```jsx
// ❌ 错误
const [form, setForm] = useState({ items: [{ planQty: 0, ... }] });

// ✅ 正确
const [form, setForm] = useState({ items: [{ planQty: '', ... }] });
```

新增行同理：`addItem` 里 `planQty: 0` → `planQty: ''`。

### Step 3: 加 onFocus 全选 — 点击即覆盖

```jsx
<TextField
  type="number"
  value={it.planQty ?? ''}
  placeholder="0"
  onFocus={(e) => e.target.select()}
  onChange={(e) => updateItem(idx, 'planQty', e.target.value === '' ? '' : Number(e.target.value))}
  inputProps={{ min: 0 }}
/>
```

`onFocus` 全选让用户点进去直接输入新值覆盖旧值，无需手动定位光标。

### Step 4: 提交兜底 — 空值转 0

```jsx
const payload = {
  ...form,
  items: form.items.map(it => ({
    ...it,
    planQty: it.planQty === '' || it.planQty === undefined ? 0 : Number(it.planQty),
  })),
};
```

后端接收到合法数字，不会出现 NaN 或 Invalid Date。

## 完整对照示例

### 修复前

```jsx
// State 初始化
setForm({ items: [{ materialId: '', planQty: 0, unit: '' }] });

// 添加行
const addItem = () => setForm({ ...form, items: [...form.items, { materialId: '', planQty: 0, unit: '' }] });

// 渲染
<TextField size="small" type="number" value={it.planQty || 0}
  onChange={(e) => updateItem(idx, 'planQty', Number(e.target.value))} sx={{ width: 80 }} />

// 提交
const payload = { ...form };
```

### 修复后

```jsx
// State 初始化
setForm({ items: [{ materialId: '', planQty: '', unit: '' }] });

// 添加行
const addItem = () => setForm({ ...form, items: [...form.items, { materialId: '', planQty: '', unit: '' }] });

// 渲染
<TextField size="small" type="number" value={it.planQty ?? ''} placeholder="0"
  onFocus={(e) => e.target.select()}
  onChange={(e) => updateItem(idx, 'planQty', e.target.value === '' ? '' : Number(e.target.value))}
  inputProps={{ min: 0 }} sx={{ width: 80 }} />

// 提交
const payload = {
  ...form,
  items: form.items.map(it => ({
    ...it,
    planQty: it.planQty === '' || it.planQty === undefined ? 0 : Number(it.planQty),
  })),
};
```

## 批量排查清单

收到此类 Bug 报告后，在项目中全局搜索以下模式，一次性修完所有同类问题：

```bash
# 搜索可能的问题模式
grep -rn "|| 0" --include="*.jsx" --include="*.tsx" client/src/
grep -rn "|| 0" --include="*.jsx" --include="*.tsx" src/
```

重点检查：
- `type="number"` 的 TextField
- 表格内嵌的数值输入框
- 采购/销售/库存等模块的数量字段（qty/quantity/amount/count/price）
- 初始 state 中数值字段默认设为 0 的

## 常见变体

| 场景 | 字段名示例 | 同样需要修复 |
|------|-----------|-------------|
| 采购计划数量 | planQty, quantity | ✅ |
| 销售订单数量 | orderQty, saleQty | ✅ |
| 库存数量 | stockQty, onHandQty | ✅ |
| 价格/金额 | unitPrice, totalPrice, amount | ✅ |
| 计件/计费数量 | count, num, rate | ✅ |

所有 `type="number"` 的 TextField 都应使用 `?? ''` 模式，而非 `|| 0`。
