---
name: react-tab-switch-view
description: React + MUI Tab 标签页切换方案（类似 Excel sheet 页），在同一页面内通过顶部 Tab 切换不同列表视图。当用户需要在同一页面以标签页形式切换多个数据列表（如主列表 + 已分配子记录 + 已转发子记录），每个 Tab 展示独立的完整表格，点击 Tab 切换显示对应列表时使用。触发词：Tab切换、标签页切换、sheet页效果、多视图切换、tab switch、Excel sheet页、分页签展示、标签页列表
agent_created: true
---

# React Tab Switch View

## Overview

在 React + MUI 项目中实现类似 Excel 底部 sheet 页的标签切换效果：页面顶部一排 Tab 标签，点击某个 Tab 后下方区域切换为对应的完整列表视图。适用于同一页面需要展示多个相关但独立的数据列表场景。

## When to Use

- 同一页面需要展示多个相关列表（如：主计划列表 + 已分配子计划列表 + 已转发子计划列表）
- 用户要求"像 Excel 的 sheet 页一样"切换不同视图
- 需要在只读查询视图和可操作列表之间切换
- 页面顶部或中部需要 Tab 标签，点击后切换到完整表格列表

## Implementation Steps

### Step 1: Add MUI Tabs to Imports

```jsx
// Add Tabs, Tab to existing MUI imports
import {
  // ... existing imports
  Tabs, Tab,
} from '@mui/material';
```

### Step 2: Add Tab State

```jsx
// Single source of truth for which tab is active
const [tabValue, setTabValue] = useState(0);
```

### Step 3: Add Data State for Secondary Tabs

```jsx
// State for data shown in secondary tabs (read-only)
const [childrenData, setChildrenData] = useState({ allocated: [], forwarded: [] });
```

### Step 4: Add Data Loading Function

```jsx
const loadChildren = async () => {
  try {
    const res = await api.get('/your-api/children');
    setChildrenData(res.data);
  } catch (err) { console.error(err); }
};
```

### Step 5: Trigger Data Load on Mount and After Operations

```jsx
// Load on mount
useEffect(() => {
  loadList();
  loadChildren();
}, [page, rowsPerPage]);

// After operations that change child data (allocate, forward, etc.)
// Call loadChildren() alongside loadList() to refresh tab counts
const handleAllocateSuccess = async () => {
  await loadList();
  await loadChildren(); // Refresh tab data
};
```

### Step 6: Render Tabs Component

Place the Tabs bar between the page header and the main content area:

```jsx
<Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
  <Tabs
    value={tabValue}
    onChange={(e, v) => setTabValue(v)}
    variant="scrollable"
    scrollButtons="auto"
  >
    <Tab icon={<ViewListIcon />} iconPosition="start" label="主列表" />
    <Tab
      icon={<CallSplitIcon />} iconPosition="start"
      label={`已分配子记录（${childrenData.allocated.length}）`}
    />
    <Tab
      icon={<ForwardIcon />} iconPosition="start"
      label={`已转发子记录（${childrenData.forwarded.length}）`}
    />
  </Tabs>
</Box>
```

### Step 7: Conditionally Render Content per Tab

Wrap existing main content and add new tab panels:

```jsx
{/* Tab 0: Main list (existing content) */}
{tabValue === 0 && (
  <>
    {/* Existing search bar */}
    <Card sx={{ mb: 2 }}>
      {/* ... search fields ... */}
    </Card>

    {/* Existing main table */}
    <TableContainer component={Paper}>
      {/* ... existing table ... */}
    </TableContainer>
  </>
)}

{/* Tab 1: Allocated children (read-only full table) */}
{tabValue === 1 && (
  <TableContainer component={Paper} sx={{ mt: 1 }}>
    <Table size="small">
      <TableHead>
        <TableRow>
          <TableCell>子记录编号</TableCell>
          <TableCell>源记录编号</TableCell>
          <TableCell>负责人</TableCell>
          <TableCell align="right">明细数</TableCell>
          <TableCell>状态</TableCell>
          <TableCell>创建时间</TableCell>
        </TableRow>
      </TableHead>
      <TableBody>
        {childrenData.allocated.length > 0 ? (
          childrenData.allocated.map((c) => (
            <TableRow key={c.id} hover>
              <TableCell sx={{ fontFamily: 'monospace' }}>{c.planNo}</TableCell>
              <TableCell sx={{ fontFamily: 'monospace' }}>{c.parentPlan?.planNo || '-'}</TableCell>
              <TableCell>{c.assignee?.employee?.name || c.assignee?.username || '-'}</TableCell>
              <TableCell align="right">{c._count?.items || 0}</TableCell>
              <TableCell>
                <Chip size="small" label={STATUS_MAP[c.status]?.label || c.status}
                  color={STATUS_MAP[c.status]?.color || 'default'} />
              </TableCell>
              <TableCell>{new Date(c.createdAt).toLocaleString('zh-CN')}</TableCell>
            </TableRow>
          ))
        ) : (
          <TableRow>
            <TableCell colSpan={6} align="center" sx={{ py: 4 }}>
              <Typography color="text.secondary">暂无已分配记录</Typography>
            </TableCell>
          </TableRow>
        )}
      </TableBody>
    </Table>
  </TableContainer>
)}

{/* Tab 2: Forwarded children (read-only full table) */}
{tabValue === 2 && (
  /* Similar structure to Tab 1, using childrenData.forwarded */
)}
```

## Backend API Pattern

Create a single endpoint that returns grouped child records:

```javascript
// GET /your-api/children
router.get('/children', async (req, res, next) => {
  try {
    const allocated = await prisma.yourModel.findMany({
      where: { parentPlanId: { not: null } },
      include: {
        parentPlan: { select: { id: true, planNo: true } },
        assignee: { select: { id: true, username: true, employee: { select: { name: true } } } },
        _count: { select: { items: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    // Split by type (allocate vs forward)
    const forwarded = allocated.filter(p => /* your forward condition */);
    const allocatedOnly = allocated.filter(p => /* your allocate condition */);

    res.json({ success: true, data: { allocated: allocatedOnly, forwarded } });
  } catch (err) { next(err); }
});
```

## Key Points

1. **Single tabValue state**: Use a single number (0, 1, 2...) to control which tab is active. Do not use separate boolean states.
2. **Conditional render with `{tabValue === N && (...)}`**: Wrap each tab's content in a conditional block. Do not use MUI TabPanel component (it renders all content hidden, causing unnecessary DOM bloat for large tables).
3. **Tab labels with counts**: Append `(N)` count to tab labels so users see data volume at a glance. Counts update automatically when `childrenData` refreshes.
4. **Auto-refresh after operations**: Any operation that changes child data (allocate, forward, delete) must call `loadChildren()` in addition to `loadList()` to keep tab counts in sync.
5. **Read-only secondary tabs**: Secondary tabs should be display-only. No edit/delete/operate buttons — just data presentation.
6. **Consistent table styling**: Use the same `Table`, `TableHead`, `TableBody`, `TableCell` styling as the main list for visual consistency. Use `size="small"` for compact secondary tables.
7. **Monospace font for IDs**: Use `sx={{ fontFamily: 'monospace' }}` for plan numbers, order numbers and other code-like fields.
8. **Empty state**: Always handle empty data with a friendly message row (`colSpan={N} align="center"`).
