---
name: action-buttons
description: 为 SCM 项目表格列表页的操作栏添加统一的汉字按钮（状态切换 + 编辑 + 删除），并配后端状态切换接口。适用场景：用户要求将操作栏改为中文按钮、加入状态切换功能、按钮样式优化。
agent_created: true
---

## 用途

在 xdj-scm 项目的基础数据/业务数据管理页面中，为表格操作栏添加统一的中文实心按钮，包括状态切换（启用/停用）、编辑、删除三个按钮。

## 适用场景

- 用户要求"操作栏改成汉字按钮"
- 用户要求"加入状态控制按钮"
- 用户要求"按钮样式优化"
- 用户要求"跟承运商管理界面一样的效果"

## 实现步骤

### 步骤 1：前端 — 按钮布局

在表格的「操作」列 `TableCell` 中，用 `Stack` 包裹三个 `Button`：

```jsx
import { Stack } from '@mui/material';

// 操作栏
<TableCell>
  <Stack direction="row" spacing={0.5}>
    <Button size="small" variant="contained"
      color={row.status === 'ACTIVE' ? 'warning' : 'success'}
      onClick={() => handleToggleStatus(row)}
      sx={{ minWidth: 56, fontSize: '0.75rem' }}>
      {row.status === 'ACTIVE' ? '停用' : '启用'}
    </Button>
    <Button size="small" variant="contained" color="primary"
      onClick={() => handleEdit(row)}
      sx={{ minWidth: 56, fontSize: '0.75rem' }}>
      编辑
    </Button>
    <Button size="small" variant="contained" color="error"
      onClick={() => handleDeleteConfirm(row)}
      sx={{ minWidth: 56, fontSize: '0.75rem' }}>
      删除
    </Button>
  </Stack>
</TableCell>
```

### 步骤 2：前端 — 状态切换函数

```js
const handleToggleStatus = async (item) => {
  const newStatus = item.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
  try {
    await api.put(`/模块路径/${item.id}`, {
      ...item,
      status: newStatus,
    });
    showSnackbar(newStatus === 'ACTIVE' ? '已启用' : '已停用');
    fetchList(); // 刷新列表
  } catch (err) {
    showSnackbar(err.data?.message || '状态切换失败', 'error');
  }
};
```

### 步骤 3：后端 — 状态切换无需改动

状态切换复用已有的 PUT 更新接口，只需在 body 中传 `status` 字段。如果后端不支持部分字段更新，则把完整记录字段都传过去（如示例代码中 `...item, status: newStatus`）。

### 步骤 4：构建

```bash
cd client && npm run build
pm2 restart gateway
```

## 注意事项

- `spacing={0.5}` 确保按钮之间有 4px 间距
- `minWidth: 56` 确保三个按钮宽度一致
- 启用 → 「停用」按钮用 `warning` 色（橙色），表示需要关注的操作
- 停用 → 「启用」按钮用 `success` 色（绿色），表示恢复操作
- 如果 `handleEdit` 的参数名不同（如 `openEdit`），直接替换函数名即可
- 如果删除是确认弹窗模式（非直接删除），`handleDeleteConfirm` → 打开确认弹窗；如果是直接删除，直接用 `handleDelete` 即可
